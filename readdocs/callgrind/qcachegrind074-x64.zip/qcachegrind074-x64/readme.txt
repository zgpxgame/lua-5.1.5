QCacheGrind binary for Windows 64bit
====================================

8-May-2013:

This is a precompiled build of QCacheGrind 0.7.4 - the Qt-only version of KCacheGrind.
(http://kcachegrind.sourceforge.net/html/Home.html)

The latest Windows binaries for KCacheGrind are not readily available, so I decided to build my own copy and make this available. 
The source code is distributed under the GPLv2 licence and can be found in the kcachegrind project page in Sourceforge. This software is dynamically linked to Qt 5, and the source for these libraries can be found in the link below.

Please go to the KCacheGrind site for more information on using the tool.


Deploying and running
---------------------

Extract the qcachegrind folder to any location.
Run qcachegrind.exe

You may need to install the MS Visual C++ 2012 Redistributable Package (x64) if not already. If qcachegrind does not start, this may be the issue.
Download and install this package from http://www.microsoft.com/en-us/download/details.aspx?id=30679


This build should run on:
Windows 7 SP1 x64
Windows 8 x64 (not confirmed)
Windows Vista SP2 x64 (not confirmed)


Build notes
-----------

KCachegrind 0.7.4 (05-Apr-2013)
dot - Graphviz 2.30.1 (15-Mar-2013)
Qt 5.02 (10-Apr-2013)

This was compiled with Qt 5 + MSVC2012_64 kit on 07-May-2013 
Bundled with the executable are the required QT libraries and the dot tool from the Graphviz windows distribution (http://www.graphviz.org/)

This has only been tested in Windows 7-64 SP1. Please post feedback on other platforms.
If you are running 32bit windows, you will need to download and run the 32bit version instead.


Licences
--------

kcachegrind: GPLv2 (http://kcachegrind.sourceforge.net/html/License.html)
Qt: LGPL 2.1 (http://qt-project.org/doc/qt-5.0/qtdoc/lgpl.html)
dot: EPL (http://www.graphviz.org/License.php)


Links
-----

qcachegrind 
http://kcachegrind.sourceforge.net/html/Home.html

dot.exe 
http://www.graphviz.org/

Qt 
http://qt.digia.com/

MSVC2012 Redistribution Package
http://www.microsoft.com/en-us/download/details.aspx?id=30679
